#!/usr/local/env python
from Bio.SeqIO.QualityIO import FastqGeneralIterator
count = 0
output_file="constant_cov_read2.fastq"
with open("constant_cov_read2.fq") as in_handle:
	with open(output_file, "w") as out_handle:
		for title, seq, qual in FastqGeneralIterator(in_handle):
			count += 1
			header = "@D00261:358:C9JAVANXX:2:2201:%i"%(count)
			out_handle.write("%s\n%s\n+\n%s\n)"%(header, seq, qual))
print "%i records processed"%(count)			
